﻿using MES.WPF.Client.Helpers;

namespace MES.WPF.Client.ViewModels
{
    public class MainViewModel : Observable
    {
        public MainViewModel()
        {
        }
    }
}
