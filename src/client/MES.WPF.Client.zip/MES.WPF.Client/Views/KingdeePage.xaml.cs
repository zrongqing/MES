﻿using System.Windows.Controls;
using MES.WPF.Client.Contracts.Views;

namespace MES.WPF.Client.Views;

public partial class KingdeePage : Page,IRegisterView
{
    public KingdeePage()
    {
        InitializeComponent();
    }
}

