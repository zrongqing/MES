﻿using MES.WPF.Client.Contracts.ViewModels;
using MES.WPF.Client.Helpers;

namespace MES.WPF.Client.ViewModels;

public class KingdeeViewModel : Observable,IRegisterViewModel
{
}
