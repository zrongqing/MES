﻿using System.Windows.Controls;

namespace MES.WPF.Client.Contracts.Views
{
    public interface IShellDialogWindow
    {
        Frame GetDialogFrame();
    }
}
