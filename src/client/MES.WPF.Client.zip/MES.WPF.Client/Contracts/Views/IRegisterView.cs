﻿namespace MES.WPF.Client.Contracts.Views;

public interface IRegisterView
{
    
}
