﻿namespace MES.WPF.Client.Models
{
    public enum AppTheme
    {
        Windows11Light,
        Windows11Dark,
        MaterialLight,
        MaterialDark,
        MaterialDarkBlue,
        MaterialLightBlue,
		Office2019Colorful,
        Office2019Black,
        Office2019White,
        Office2019DarkGray,
        Office2019HighContrast
    }
}
