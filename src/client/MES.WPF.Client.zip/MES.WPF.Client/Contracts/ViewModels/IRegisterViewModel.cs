﻿namespace MES.WPF.Client.Contracts.ViewModels;

public interface IRegisterViewModel
{
    
}
