﻿namespace MES.WPF.Client.Contracts.Services
{
    public interface ISystemService
    {
        void OpenInWebBrowser(string url);
    }
}
